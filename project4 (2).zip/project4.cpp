//For Visual Studios
#ifdef _MSC_VER
#define _CRT_SECURE_NO_WARNINGS
#endif

#include "glad/glad.h"  //Include order can matter here
#include <SDL3/SDL.h>
#include <SDL3/SDL_opengl.h>
#include <SDL3/SDL_mouse.h>
#include <cstdio>


#define GLM_FORCE_RADIANS
#include "glm/glm.hpp"
#include "glm/gtc/matrix_transform.hpp"
#include "glm/gtc/type_ptr.hpp"

#include <cstdio>
#include <iostream>
#include <fstream>
#include <string>
#include <vector>

bool saveOutput = true;
float timePast = 0;

// Shader sources
const GLchar* vertexSource =
  "#version 150 core\n"
  "in vec3 position;"
  "uniform vec3 inColor = vec3(0.f,0.7f,0.f);"
  "in vec3 inNormal;"
  "out vec3 Color;"
  "out vec3 normal;"
  "out vec3 pos;"
  "uniform mat4 model;"
  "uniform mat4 view;"
  "uniform mat4 proj;"
  "void main() {"
  "   Color = inColor;"
  "   gl_Position = proj * view * model * vec4(position,1.0);"
  "   pos = (view * model * vec4(position,1.0)).xyz;"
  "   vec4 norm4 = transpose(inverse(view*model)) * vec4(inNormal,0.0);" //Or Just: normal = normalize(view*model* vec4(inNormal,0.0)).xyz; //faster, but wrong if skew or non-uniform scale in model matrix
  "   normal = normalize(norm4.xyz);"
  "}";

const GLchar* fragmentSource =
  "#version 150 core\n"
  "in vec3 Color;"
  "in vec3 normal;"
  "in vec3 pos;"
  "uniform vec3 lightDir;"
  "out vec4 outColor;"
  "const float ambient = .3;"
  "void main() {"
  "   vec3 diffuseC = Color*max(dot(lightDir,normal),0.0);"
  "   vec3 ambC = Color*ambient;"
  "   vec3 viewDir = normalize(-pos);" //We know the eye is at (0,0)! [Q: Why?]
  "   vec3 reflectDir = reflect(viewDir,normal);"
  "   float spec = max(dot(reflectDir,-lightDir),0.0);"
  "   if (dot(lightDir,normal) <= 0.0) spec = 0;"
  "   vec3 specC = vec3(1.0,1.0,1.0)*pow(spec,4);"
  "   outColor = vec4(diffuseC+ambC+specC, 1.0);"
  "}";
    
bool fullscreen = false;
bool flyingMode = false;
int screen_width = 800;
int screen_height = 600;
int mapWidth = 7;
int mapHeight = 7;
//camera stuff
glm::vec3 cameraPos = glm::vec3(0.0f, 0.0f, 0.0f); 
glm::vec3 cameraFront = glm::vec3(0.0f, 0.0f, 1.0f);
glm::vec3 cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);
float horizontalRotation = -90.0f; 
float verticalRotation = 0.0f;
float cameraSpeed = 2.5f;
//mouse stuff
float mouseSensitivity = 0.1f;
int lastX = 400; 
int lastY = 300; 
bool firstMouse = true;
const float PLAYER_RADIUS = 0.4f;
glm::vec3 worldLightDir = glm::normalize(glm::vec3(1.0f, 1.0f, 1.0f));
int level = 1;
bool levelComplete=false;
bool hasAkey = false;
bool hasBkey = false;
bool hasCkey = false;
bool hasDkey = false;
bool hasEkey = false;

char window_title[] = "My OpenGL Program";

float avg_render_time = 0;

void Win2PPM(int width, int height);

struct Model {
  GLuint vao;
  GLuint vbo;
  int numVertices;
  float* modelData; // Keep track of the allocated data for cleanup
};
struct Interactable{
  int x;
  int y;
  char type;
  Interactable(int x, int y, char type):x(x), y(y), type(type){}
  void setType(char newType){
    type = newType;
  }
};

glm::vec3 checkWallCollision(const glm::vec3& proposedPos, std::vector<Interactable>& map) {
  glm::vec3 newPos = proposedPos;

  for (auto& interactable : map) {
    if (interactable.type == 'S' || interactable.type == '-'){
      continue;
    } 
    //otherwise we check if we are colliding with the interactable
    float wallCenterX = static_cast<float>(interactable.x);
    float wallCenterZ = static_cast<float>(interactable.y);
    glm::vec3 closestPoint;
    closestPoint.x = glm::clamp(newPos.x, wallCenterX - 0.5f, wallCenterX + 0.5f);
    closestPoint.y = newPos.y; 
    closestPoint.z = glm::clamp(newPos.z, wallCenterZ - 0.5f, wallCenterZ + 0.5f);
    glm::vec3 distance = newPos - closestPoint;
    float distanceSq = glm::dot(distance, distance);

    if (distanceSq < PLAYER_RADIUS * PLAYER_RADIUS) {//collision
      bool lockedDoor = (interactable.type == 'A' && !hasAkey)||
                        (interactable.type == 'B' && !hasBkey)||
                        (interactable.type == 'C' && !hasCkey)||
                        (interactable.type == 'D' && !hasCkey)||
                        (interactable.type == 'E' && !hasEkey);
      bool unlockedDoor = (interactable.type == 'A' && hasAkey)||
                          (interactable.type == 'B' && hasBkey)||
                          (interactable.type == 'C' && hasCkey)||
                          (interactable.type == 'D' && hasCkey)||
                          (interactable.type == 'E' && hasEkey);
      if (unlockedDoor){//we are at the door and have the key
        interactable.setType('-');//remove the door from the map
        printf("Door opened!\n");
        continue;
      }else if (interactable.type == 'W' || lockedDoor) {//if we are at a wall or a locked door push the player back
        float dist = glm::sqrt(distanceSq);
        float penetrationDepth = PLAYER_RADIUS - dist;
        if (dist > glm::epsilon<float>()) { 
          glm::vec3 pushOutVector = (distance / dist) * penetrationDepth;
          newPos += pushOutVector;
        } else {//edge case
          newPos.x += PLAYER_RADIUS; 
        }
      }else if (interactable.type == 'a'){//else we could be at a key or the goal so do appropriate things:
        hasAkey = true;
        printf("'A' key secured!\n");
        interactable.setType('-');//key is no longer there
        continue;
      }else if (interactable.type == 'b'){
        hasBkey = true;
        printf("'B' key secured!\n");
        interactable.setType('-');//key is no longer there
        continue;
      }else if (interactable.type == 'c'){
        hasCkey = true;
        printf("'C' key secured!\n");
        interactable.setType('-');//key is no longer there
        continue;
      }else if (interactable.type == 'd'){
        hasDkey = true;
        printf("'D' key secured!\n");
        interactable.setType('-');//key is no longer there
        continue;
      }else if (interactable.type == 'e'){
        hasEkey = true;
        printf("'E' key secured!\n");
        interactable.setType('-');//key is no longer there
        continue;
      }else if (interactable.type == 'G'){
        std::cout << "Level " << level << " Complete!" << std::endl;
        levelComplete=true;
        continue;
      }
    }
  }
  return newPos;
}


std::vector<Interactable> loadMap(const char* file_name) {
  std::vector<Interactable> map;

  std::ifstream mapFile(file_name);
  if (!mapFile.is_open()) {
      printf("ERROR: Map file '%s' not found or could not be opened.\n", file_name);
      return map; // Return invalid model
  }

  if (!(mapFile >> mapWidth >> mapHeight)){
    std::cerr << "Error: width and height requires 2 numeric parameters." << std::endl;
  }
  std::string line;
  std::getline(mapFile,line);
  
  for (int row = 0; row<mapHeight; row++){
    if (!std::getline(mapFile, line)){
      std::cerr << "Error: row missing in map file" << std::endl;
    }
    if (line.length()<mapWidth){
      std::cerr << "Error: Data missing in row." << std::endl;
    }
    for (int col= 0; col<mapWidth; col++){
      if (line[col]=='W'){
        //make wall, i.e. a cube at this spot. We can use the cube model!
        Interactable wall = Interactable(col,row,'W');
        map.push_back(wall);
      }else if (line[col]=='S'){
        cameraPos.x = static_cast<float>(col);
        cameraPos.z = static_cast<float>(row);
        //start point
        // startPoint = Interactable(col,row,'S');
      }else if (line[col]=='G'){
        //end point
        Interactable goal = Interactable(col,row,'G');
        map.push_back(goal);
      }else if (line[col]=='A'){
        //make wall, i.e. a cube at this spot. We can use the cube model!
        map.push_back(Interactable(col,row,'A'));
      }else if (line[col]=='B'){
        //B door
        map.push_back(Interactable(col,row,'B'));
      }else if (line[col]=='C'){
        //C door
        map.push_back(Interactable(col,row,'C'));
      }else if (line[col]=='D'){
        //D door
        map.push_back(Interactable(col,row,'D'));
      }else if (line[col]=='E'){
        //E door
        map.push_back(Interactable(col,row,'E'));
      }else if (line[col]=='a'){
        //a key
        map.push_back(Interactable(col,row,'a'));
      }else if (line[col]=='b'){
        //b key
        map.push_back(Interactable(col,row,'b'));
      }else if (line[col]=='c'){
        //c key
        map.push_back(Interactable(col,row,'c'));
      }else if (line[col]=='d'){
        //d key
        map.push_back(Interactable(col,row,'d'));
      }else if (line[col]=='e'){
        //e key
        map.push_back(Interactable(col,row,'e'));
      }
    }
  }

  return map;


}

Model loadModel(const char* file_name, GLuint shaderProgram) {
  Model model;
  model.vao = 0;
  model.vbo = 0;
  model.numVertices = 0;
  model.modelData = nullptr;

  // --- Model Loading with Error Checking ---
  std::ifstream modelFile(file_name);
  if (!modelFile.is_open()) {
      printf("ERROR: Model file '%s' not found or could not be opened.\n", file_name);
      return model; // Return invalid model
  }

  int numModelParams = 0;
  modelFile >> numModelParams;
  if (numModelParams <= 0) {
      printf("ERROR: Model file is empty or does not start with a valid float count.\n");
      modelFile.close();
      return model;
  }

  model.modelData = new float[numModelParams];
  for (int i = 0; i < numModelParams; i++){
      modelFile >> model.modelData[i];
  }
  modelFile.close();

  printf("Model '%s' total float count: %d\n", file_name, numModelParams);
  const int paramsPerVertex = 8; // Assumes X,Y,Z, U,V, Nx,Ny,Nz
  model.numVertices = numModelParams / paramsPerVertex;

  // --- OpenGL Setup (VAO/VBO) ---
  glGenVertexArrays(1, &model.vao);
  glBindVertexArray(model.vao);

  glGenBuffers(1, &model.vbo);
  glBindBuffer(GL_ARRAY_BUFFER, model.vbo);
  glBufferData(GL_ARRAY_BUFFER, numModelParams * sizeof(float), model.modelData, GL_STATIC_DRAW);

  // --- Vertex Attribute Setup (same as before) ---
  GLint posAttrib = glGetAttribLocation(shaderProgram, "position");
  // Attribute, vals/attrib., type, is_normalized, stride, offset
  glVertexAttribPointer(posAttrib, 3, GL_FLOAT, GL_FALSE, paramsPerVertex * sizeof(float), 0);
  glEnableVertexAttribArray(posAttrib);

  GLint normAttrib = glGetAttribLocation(shaderProgram, "inNormal");
  // Normal data starts after 5 floats (X,Y,Z,U,V)
  glVertexAttribPointer(normAttrib, 3, GL_FLOAT, GL_FALSE, paramsPerVertex * sizeof(float), (void*)(5*sizeof(float)));
  glEnableVertexAttribArray(normAttrib);

  glBindVertexArray(0); // Unbind the VAO

  return model;
}

void cleanupModel(Model& model) {
  glDeleteBuffers(1, &model.vbo);
  glDeleteVertexArrays(1, &model.vao);
  delete[] model.modelData;
  model.modelData = nullptr;
}

// main function updated for SDL3 and with debugging checks

int main(int argc, char *argv[]){
  SDL_Init(SDL_INIT_VIDEO);  //Initialize Graphics (for OpenGL)

  //Print the version of SDL we are using (should be 3.x or higher)
  const int sdl_linked = SDL_GetVersion();
  printf("\nCompiled against SDL version %d.%d.%d ...\n", SDL_VERSIONNUM_MAJOR(SDL_VERSION), SDL_VERSIONNUM_MINOR(SDL_VERSION), SDL_VERSIONNUM_MICRO(SDL_VERSION));
  printf("Linking against SDL version %d.%d.%d.\n", SDL_VERSIONNUM_MAJOR(sdl_linked), SDL_VERSIONNUM_MINOR(sdl_linked), SDL_VERSIONNUM_MICRO(sdl_linked));

  //Ask SDL to get a recent version of OpenGL (3.2 or greater)
  SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_CORE);
  SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 3);
  SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 2);

  //Create a window (title, width, height, flags)
  SDL_Window* window = SDL_CreateWindow(window_title, screen_width, screen_height, SDL_WINDOW_OPENGL);
  float aspect = screen_width/(float)screen_height; //aspect ratio (needs to be updated if the window is resized)
  //The above window cannot be resized which makes some code slightly easier.
  //Below we show how to make a full screen window or allow resizing
  //SDL_Window* window = SDL_CreateWindow(window_title, screen_width, screen_height, SDL_WINDOW_FULLSCREEN|SDL_WINDOW_OPENGL);
  //SDL_Window* window = SDL_CreateWindow(window_title, screen_width, screen_height, SDL_WINDOW_RESIZABLE|SDL_WINDOW_OPENGL);
  if (!window) {
    printf("SDL_CreateWindow Error: %s\n", SDL_GetError());
    SDL_Quit();
    return 1;
  }

	//Create a context to draw in
	SDL_GLContext context = SDL_GL_CreateContext(window);
	SDL_SetWindowRelativeMouseMode(window,true);

	if (gladLoadGLLoader((GLADloadproc)SDL_GL_GetProcAddress)){
    printf("\nOpenGL loaded\n");
    printf("Vendor:   %s\n", glGetString(GL_VENDOR));
    printf("Renderer: %s\n", glGetString(GL_RENDERER));
    printf("Version:  %s\n\n", glGetString(GL_VERSION));
  }
  else {
    printf("ERROR: Failed to initialize OpenGL context.\n");
    return -1;
  }

  // model loading stuff here

  //Load the vertex Shader
	GLuint vertexShader = glCreateShader(GL_VERTEX_SHADER); 
	glShaderSource(vertexShader, 1, &vertexSource, NULL);
	glCompileShader(vertexShader);
	
	//Let's double check the shader compiled 
	GLint status;
	glGetShaderiv(vertexShader, GL_COMPILE_STATUS, &status);
	if (!status){
		char buffer[512];
		glGetShaderInfoLog(vertexShader, 512, NULL, buffer);
		printf("Vertex Shader Compile Failed. Info:\n\n%s\n",buffer);
	}
	
	GLuint fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
	glShaderSource(fragmentShader, 1, &fragmentSource, NULL);
	glCompileShader(fragmentShader);
	
	//Double check the shader compiled 
	glGetShaderiv(fragmentShader, GL_COMPILE_STATUS, &status);
	if (!status){
		char buffer[512];
		glGetShaderInfoLog(fragmentShader, 512, NULL, buffer);
		printf("Fragment Shader Compile Failed. Info:\n\n%s\n",buffer);
	}
	
	//Join the vertex and fragment shaders together into one program
	GLuint shaderProgram = glCreateProgram();
	glAttachShader(shaderProgram, vertexShader);
	glAttachShader(shaderProgram, fragmentShader);
	glBindFragDataLocation(shaderProgram, 0, "outColor"); // set output
	glLinkProgram(shaderProgram);
	glUseProgram(shaderProgram);

  GLint lightDirLoc = glGetUniformLocation(shaderProgram, "lightDir");
  GLint objectColorLoc = glGetUniformLocation(shaderProgram, "inColor");

  //If you need a second VAO (e.g., if some of the models are stored in a second format)
  //Here is what that looks like--
  //GLuint vao2;  
	//glGenVertexArrays(1, &vao2); //Create the VAO
  //glBindVertexArray(vao2); //Bind the above created VAO to the current context
  //  Creat VBOs ... 
  //  Set-up attributes ...
  //glBindVertexArray(0); //Unbind the VAO
	
  std::vector<Interactable> map = loadMap("models/map1.txt");
  Model cube = loadModel("models/cube.txt", shaderProgram);
  Model teapot = loadModel("models/teapot.txt",shaderProgram);
  Model knot = loadModel("models/knot.txt",shaderProgram);
  Model square = loadModel("models/square.txt",shaderProgram);

	glEnable(GL_DEPTH_TEST);  
	
	//Event Loop (Loop forever processing each event as fast as possible)
	SDL_Event windowEvent;
    bool quit = false;
	while (!quit){
    if (levelComplete){//if the level is complete, load the next map and set level complete back to false
      levelComplete = false;
      hasAkey=false;
      hasBkey = false;
      hasCkey = false;
      hasDkey = false;
      hasEkey = false;
      level +=1;
      std::string filename = "models/map" + std::to_string(level) + ".txt"; 
      map = loadMap(filename.c_str());
    }
    float t_start = SDL_GetTicks();
    float currentFrame = (float)SDL_GetTicks() / 1000.0f;
    float deltaTime = currentFrame - timePast;
    timePast = currentFrame;
    const bool* state = SDL_GetKeyboardState(NULL);

    glm::vec3 oldCameraPos = cameraPos;
    //if in walking mode, we want to ignore the Y component of camera front
    glm::vec3 cameraFrontXZ = cameraFront;
    cameraFrontXZ.y = 0.0f;
    cameraFrontXZ = glm::normalize(cameraFrontXZ);
    glm::vec3 use = flyingMode? cameraFront : cameraFrontXZ;
    // WASD
    float velocity = cameraSpeed * deltaTime;
    if (state[SDL_SCANCODE_W])
        cameraPos -= velocity*use;
    if (state[SDL_SCANCODE_S])
        cameraPos += velocity * use;
    if (state[SDL_SCANCODE_A])
        cameraPos += glm::normalize(glm::cross(use, cameraUp)) * velocity;
    if (state[SDL_SCANCODE_D])
        cameraPos -= glm::normalize(glm::cross(use, cameraUp)) * velocity;
    // Optional: Vertical Movement (Space/Ctrl)
    if (state[SDL_SCANCODE_SPACE])
        cameraPos += velocity * cameraUp;
    if (state[SDL_SCANCODE_LCTRL]) // Left Control
        cameraPos -= velocity * cameraUp;


    if (oldCameraPos != cameraPos) {
      cameraPos = checkWallCollision(cameraPos, map); //if we moved, check if we moved into an interactable
    }

      while (SDL_PollEvent(&windowEvent)){
				// List of keycodes: https://wiki.libsdl.org/SDL_Keycode - You can get events from many special keys
				// Scancode refers to a keyboard position, keycode refers to the letter (e.g., EU keyboards)
        if (windowEvent.type == SDL_EVENT_QUIT) quit = true;
        if (windowEvent.type == SDL_EVENT_KEY_UP && windowEvent.key.key == SDLK_ESCAPE)
          quit = true;
        if (windowEvent.type == SDL_EVENT_KEY_UP && windowEvent.key.key == SDLK_F) { // Toggle fullscreen with 'F' key
          fullscreen = !fullscreen;
          SDL_SetWindowFullscreen(window, fullscreen ? SDL_WINDOW_FULLSCREEN : 0);
        }
        if (windowEvent.type == SDL_EVENT_KEY_UP && windowEvent.key.key == SDLK_LSHIFT) { 
          flyingMode = !flyingMode;
          if (!flyingMode) {
            cameraPos.y = 0.0f; 
          }
          printf("Switched to %s\n", flyingMode ? "Flying Mode" : "Walking Mode");
        }
        if (windowEvent.type == SDL_EVENT_MOUSE_MOTION) {
          int xPos = windowEvent.motion.x;
          int yPos = windowEvent.motion.y;

          float xOffset = (float)windowEvent.motion.xrel;
          float yOffset = (float)windowEvent.motion.yrel;

          xOffset *= mouseSensitivity;
          yOffset *= mouseSensitivity;

          horizontalRotation += xOffset;
          verticalRotation -= yOffset;

          if (verticalRotation > 89.0f) verticalRotation = 89.0f;
          if (verticalRotation < -89.0f) verticalRotation = -89.0f;

          glm::vec3 front;
          front.x = cos(glm::radians(horizontalRotation)) * cos(glm::radians(verticalRotation));
          front.y = sin(glm::radians(verticalRotation));
          front.z = sin(glm::radians(horizontalRotation)) * cos(glm::radians(verticalRotation));
          cameraFront = glm::normalize(front);
        }

      }
    
    // Clear the screen to target color and clear depth buffer
    glClearColor(.2f, 0.4f, 0.8f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
    if (!saveOutput) timePast = SDL_GetTicks()/1000.f; 
    else timePast += .07;
    

    // --- View and Projection Matrices (Only need to set these once per frame) ---
    glm::mat4 view = glm::lookAt(
      cameraPos,    //Cam Position
      cameraPos+cameraFront,  //Look At Point
      cameraUp); //Up Vector
    glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "view"), 1, GL_FALSE, glm::value_ptr(view));

    glm::vec3 viewLightDir = glm::mat3(view) * worldLightDir;
    viewLightDir = glm::normalize(viewLightDir);
    glUniform3fv(lightDirLoc, 1, glm::value_ptr(viewLightDir));

    glm::mat4 proj = glm::perspective(glm::radians(45.0f), aspect, 0.1f, 10.0f); //FOV, aspect, near, far
    glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "proj"), 1, GL_FALSE, glm::value_ptr(proj));

    //draw map
    glm::mat4 model_floor = glm::mat4(1.0f);
    model_floor = glm::translate(model_floor, glm::vec3(
        static_cast<float>(mapWidth - 1) / 2.0f, 
        -0.5f, // Y position
        static_cast<float>(mapHeight - 1) / 2.0f 
    ));
    model_floor = glm::scale(model_floor, glm::vec3(
        static_cast<float>(mapWidth) / 2.0f, 
        0.01f,                               
        static_cast<float>(mapHeight) / 2.0f 
    ));
    glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "model"), 1, GL_FALSE, glm::value_ptr(model_floor));
    glUniform3f(objectColorLoc, 0.1f, 0.1f, 0.1f);
    glBindVertexArray(square.vao);
    glDrawArrays(GL_TRIANGLES, 0, square.numVertices);
    glBindVertexArray(0);
    for (int i=0; i<map.size(); i++){
      if (map[i].type == 'W'){
        glm::mat4 model_cube = glm::mat4(1);
        model_cube = glm::translate(model_cube, glm::vec3(
          static_cast<float>(map[i].x), 
          0.0f,
          static_cast<float>(map[i].y) 
        ));
        glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "model"), 1, GL_FALSE, glm::value_ptr(model_cube));
        glUniform3f(objectColorLoc, 0.8f, 0.8f, 0.8f);
        glBindVertexArray(cube.vao);
        glDrawArrays(GL_TRIANGLES, 0, cube.numVertices);
        glBindVertexArray(0);
      }else if (map[i].type == 'A'){
        glm::mat4 model_teapot = glm::mat4(1);
        model_teapot = glm::translate(model_teapot, glm::vec3(
          static_cast<float>(map[i].x), 
          0.0f,
          static_cast<float>(map[i].y) 
        ));
        glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "model"), 1, GL_FALSE, glm::value_ptr(model_teapot));
        glUniform3f(objectColorLoc, 0.8f, 0.4f, 0.4f);
        glBindVertexArray(teapot.vao);
        glDrawArrays(GL_TRIANGLES, 0, teapot.numVertices);
        glBindVertexArray(0);
      }else if (map[i].type == 'a'){
        glm::mat4 model_teapot = glm::mat4(1);
        model_teapot = glm::translate(model_teapot, glm::vec3(
          static_cast<float>(map[i].x), 
          0.0f,
          static_cast<float>(map[i].y) 
        ));
        model_teapot = glm::scale(model_teapot, glm::vec3(.3f, .3f, .3f));
        glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "model"), 1, GL_FALSE, glm::value_ptr(model_teapot));
        glUniform3f(objectColorLoc, 0.8f, 0.4f, 0.4f);
        glBindVertexArray(teapot.vao);
        glDrawArrays(GL_TRIANGLES, 0, teapot.numVertices);
        glBindVertexArray(0);
      }else if (map[i].type == 'B'){
        glm::mat4 model = glm::mat4(1);
        model = glm::translate(model, glm::vec3(
          static_cast<float>(map[i].x), 
          0.0f,
          static_cast<float>(map[i].y) 
        ));
        glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "model"), 1, GL_FALSE, glm::value_ptr(model));
        glUniform3f(objectColorLoc, 0.4f, 0.8f, 0.4f);
        glBindVertexArray(knot.vao);
        glDrawArrays(GL_TRIANGLES, 0, knot.numVertices);
        glBindVertexArray(0);
      }else if (map[i].type == 'b'){
        glm::mat4 model = glm::mat4(1);
        model = glm::translate(model, glm::vec3(
          static_cast<float>(map[i].x), 
          0.0f,
          static_cast<float>(map[i].y) 
        ));
        model = glm::scale(model, glm::vec3(.3f, .3f, .3f));
        glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "model"), 1, GL_FALSE, glm::value_ptr(model));
        glUniform3f(objectColorLoc, 0.4f, 0.8f, 0.4f);
        glBindVertexArray(knot.vao);
        glDrawArrays(GL_TRIANGLES, 0, knot.numVertices);
        glBindVertexArray(0);
      }else if (map[i].type == 'C'){
        glm::mat4 model = glm::mat4(1);
        model = glm::translate(model, glm::vec3(
          static_cast<float>(map[i].x), 
          0.0f,
          static_cast<float>(map[i].y) 
        ));
        glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "model"), 1, GL_FALSE, glm::value_ptr(model));
        glUniform3f(objectColorLoc, 0.7f, 0.3f, 0.5f);
        glBindVertexArray(knot.vao);
        glDrawArrays(GL_TRIANGLES, 0, knot.numVertices);
        glBindVertexArray(0);
      }else if (map[i].type == 'c'){
        glm::mat4 model = glm::mat4(1);
        model = glm::translate(model, glm::vec3(
          static_cast<float>(map[i].x), 
          0.0f,
          static_cast<float>(map[i].y) 
        ));
        model = glm::scale(model, glm::vec3(.3f, .3f, .3f));
        glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "model"), 1, GL_FALSE, glm::value_ptr(model));
        glUniform3f(objectColorLoc, 0.7f, 0.3f, 0.5f);
        glBindVertexArray(knot.vao);
        glDrawArrays(GL_TRIANGLES, 0, knot.numVertices);
        glBindVertexArray(0);
      }else if (map[i].type == 'D'){
        glm::mat4 model = glm::mat4(1);
        model = glm::translate(model, glm::vec3(
          static_cast<float>(map[i].x), 
          0.0f,
          static_cast<float>(map[i].y) 
        ));
        glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "model"), 1, GL_FALSE, glm::value_ptr(model));
        glUniform3f(objectColorLoc, 0.3f, 0.7f, 0.6f);
        glBindVertexArray(knot.vao);
        glDrawArrays(GL_TRIANGLES, 0, knot.numVertices);
        glBindVertexArray(0);
      }else if (map[i].type == 'd'){
        glm::mat4 model = glm::mat4(1);
        model = glm::translate(model, glm::vec3(
          static_cast<float>(map[i].x), 
          0.0f,
          static_cast<float>(map[i].y) 
        ));
        model = glm::scale(model, glm::vec3(.3f, .3f, .3f));
        glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "model"), 1, GL_FALSE, glm::value_ptr(model));
        glUniform3f(objectColorLoc, 0.3f, 0.7f, 0.6f);
        glBindVertexArray(knot.vao);
        glDrawArrays(GL_TRIANGLES, 0, knot.numVertices);
        glBindVertexArray(0);
      }else if (map[i].type == 'E'){
        glm::mat4 model = glm::mat4(1);
        model = glm::translate(model, glm::vec3(
          static_cast<float>(map[i].x), 
          0.0f,
          static_cast<float>(map[i].y) 
        ));
        glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "model"), 1, GL_FALSE, glm::value_ptr(model));
        glUniform3f(objectColorLoc, 0.5f, 0.3f, 0.7f);
        glBindVertexArray(knot.vao);
        glDrawArrays(GL_TRIANGLES, 0, knot.numVertices);
        glBindVertexArray(0);
      }else if (map[i].type == 'e'){
        glm::mat4 model = glm::mat4(1);
        model = glm::translate(model, glm::vec3(
          static_cast<float>(map[i].x), 
          0.0f,
          static_cast<float>(map[i].y) 
        ));
        model = glm::scale(model, glm::vec3(.3f, .3f, .3f));
        glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "model"), 1, GL_FALSE, glm::value_ptr(model));
        glUniform3f(objectColorLoc, 0.5f, 0.3f, 0.7f);
        glBindVertexArray(knot.vao);
        glDrawArrays(GL_TRIANGLES, 0, knot.numVertices);
        glBindVertexArray(0);
      }
          
    }

    //draw keys in corner
    if (hasEkey){
      float distance_from_camera = .5f; 
      float right_offset = 0.0f;         
      float up_offset = 0.0f;            
      glm::vec3 cameraRight = glm::normalize(glm::cross(cameraFront, cameraUp));
      glm::vec3 hud_pos = cameraPos + 
                          (cameraFront * distance_from_camera) + 
                          (cameraRight * right_offset) + 
                          (cameraUp * up_offset);
      glm::mat4 model_corner = glm::mat4(1.0f);
      model_corner = glm::translate(model_corner, hud_pos);
      glm::mat4 camera_rot = glm::lookAt(glm::vec3(0), cameraFront, cameraUp); 
      model_corner *= glm::inverse(camera_rot);
      model_corner = glm::scale(model_corner, glm::vec3(0.1f)); 
      glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "model"), 1, GL_FALSE, glm::value_ptr(model_corner));
      glUniform3f(objectColorLoc, 0.5f, 0.3f, 0.7f);
      glBindVertexArray(knot.vao); 
      glDrawArrays(GL_TRIANGLES, 0, knot.numVertices);
      glBindVertexArray(0);
  
    }else if (hasDkey){
      float distance_from_camera = .5f; 
      float right_offset = 0.0f;         
      float up_offset = 0.0f;            
      glm::vec3 cameraRight = glm::normalize(glm::cross(cameraFront, cameraUp));
      glm::vec3 hud_pos = cameraPos + 
                          (cameraFront * distance_from_camera) + 
                          (cameraRight * right_offset) + 
                          (cameraUp * up_offset);
      glm::mat4 model_corner = glm::mat4(1.0f);
      model_corner = glm::translate(model_corner, hud_pos);
      glm::mat4 camera_rot = glm::lookAt(glm::vec3(0), cameraFront, cameraUp); 
      model_corner *= glm::inverse(camera_rot);
      model_corner = glm::scale(model_corner, glm::vec3(0.1f)); 
      glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "model"), 1, GL_FALSE, glm::value_ptr(model_corner));
      glUniform3f(objectColorLoc, 0.3f, 0.7f, 0.6f);
      glBindVertexArray(knot.vao); 
      glDrawArrays(GL_TRIANGLES, 0, knot.numVertices);
      glBindVertexArray(0);
  
    }else if (hasCkey){
      float distance_from_camera = .5f; 
      float right_offset = 0.0f;         
      float up_offset = 0.0f;            
      glm::vec3 cameraRight = glm::normalize(glm::cross(cameraFront, cameraUp));
      glm::vec3 hud_pos = cameraPos + 
                          (cameraFront * distance_from_camera) + 
                          (cameraRight * right_offset) + 
                          (cameraUp * up_offset);
      glm::mat4 model_corner = glm::mat4(1.0f);
      model_corner = glm::translate(model_corner, hud_pos);
      glm::mat4 camera_rot = glm::lookAt(glm::vec3(0), cameraFront, cameraUp); 
      model_corner *= glm::inverse(camera_rot);
      model_corner = glm::scale(model_corner, glm::vec3(0.1f)); 
      glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "model"), 1, GL_FALSE, glm::value_ptr(model_corner));
      glUniform3f(objectColorLoc, 0.7f, 0.3f, 0.5f);
      glBindVertexArray(knot.vao); 
      glDrawArrays(GL_TRIANGLES, 0, knot.numVertices);
      glBindVertexArray(0);
  
    }else if (hasBkey){
      float distance_from_camera = .5f; 
      float right_offset = 0.0f;         
      float up_offset = 0.0f;            
      glm::vec3 cameraRight = glm::normalize(glm::cross(cameraFront, cameraUp));
      glm::vec3 hud_pos = cameraPos + 
                          (cameraFront * distance_from_camera) + 
                          (cameraRight * right_offset) + 
                          (cameraUp * up_offset);
      glm::mat4 model_corner = glm::mat4(1.0f);
      model_corner = glm::translate(model_corner, hud_pos);
      glm::mat4 camera_rot = glm::lookAt(glm::vec3(0), cameraFront, cameraUp); 
      model_corner *= glm::inverse(camera_rot);
      model_corner = glm::scale(model_corner, glm::vec3(0.1f)); 
      glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "model"), 1, GL_FALSE, glm::value_ptr(model_corner));
      glUniform3f(objectColorLoc, 0.4f, 0.8f, 0.4f);
      glBindVertexArray(knot.vao); 
      glDrawArrays(GL_TRIANGLES, 0, knot.numVertices);
      glBindVertexArray(0);
  
    }else if (hasAkey){
      float distance_from_camera = .5f; 
      float right_offset = 0.0f;         
      float up_offset = 0.0f;            
      glm::vec3 cameraRight = glm::normalize(glm::cross(cameraFront, cameraUp));
      glm::vec3 hud_pos = cameraPos + 
                          (cameraFront * distance_from_camera) + 
                          (cameraRight * right_offset) + 
                          (cameraUp * up_offset);
      glm::mat4 model_corner = glm::mat4(1.0f);
      model_corner = glm::translate(model_corner, hud_pos);
      glm::mat4 camera_rot = glm::lookAt(glm::vec3(0), cameraFront, cameraUp); 
      model_corner *= glm::inverse(camera_rot);
      model_corner = glm::scale(model_corner, glm::vec3(0.1f)); 
      glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "model"), 1, GL_FALSE, glm::value_ptr(model_corner));
      glUniform3f(objectColorLoc, 0.8f, 0.4f, 0.4f);
      glBindVertexArray(teapot.vao); 
      glDrawArrays(GL_TRIANGLES, 0, teapot.numVertices);
      glBindVertexArray(0);
  
    }


    if (saveOutput) Win2PPM(screen_width,screen_height);
    if (saveOutput) timePast += .05; //Fix framerate at 20 FPS
    SDL_GL_SwapWindow(window); //Double buffering

    float t_end = SDL_GetTicks();
    char update_title[100];
    float time_per_frame = t_end-t_start;
    avg_render_time = .98f*avg_render_time + .02f*time_per_frame;  //Weighted average for smoothing
  	snprintf(update_title, 100, "%s [Update: %3.0f ms]",window_title,avg_render_time);
    SDL_SetWindowTitle(window, update_title);
	}
	

  //Clean Up
  cleanupModel(cube);

	glDeleteProgram(shaderProgram);
  glDeleteShader(fragmentShader);
  glDeleteShader(vertexShader);
	SDL_GL_DestroyContext(context);
	SDL_Quit();
	return 0;
}


//Write out PPM image from screen
void Win2PPM(int width, int height){
	char outdir[10] = "out/"; //Must be defined!
	int i,j;
	FILE* fptr;
    static int counter = 0;
    char fname[32];
    unsigned char *image;
    
    /* Allocate our buffer for the image */
    image = (unsigned char *)malloc(3*width*height*sizeof(char));
    if (image == NULL) {
      fprintf(stderr,"ERROR: Failed to allocate memory for image\n");
    }
    
    /* Open the file */
    snprintf(fname, sizeof(fname), "%simage_%04d.ppm",outdir,counter);
    if ((fptr = fopen(fname,"w")) == NULL) {
      fprintf(stderr,"ERROR: Failed to open file to write image\n");
    }
    
    /* Copy the image into our buffer */
    glReadBuffer(GL_BACK);
    glReadPixels(0,0,width,height,GL_RGB,GL_UNSIGNED_BYTE,image);
    
    /* Write the PPM file */
    fprintf(fptr,"P6\n%d %d\n255\n",width,height);
    for (j=height-1;j>=0;j--) {
      for (i=0;i<width;i++) {
         fputc(image[3*j*width+3*i+0],fptr);
         fputc(image[3*j*width+3*i+1],fptr);
         fputc(image[3*j*width+3*i+2],fptr);
      }
    }
    
    free(image);
    fclose(fptr);
    counter++;
}